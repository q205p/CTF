import { HeroImageBackground } from "./Hero";

export default function Home() {
  return (
    <>
      <HeroImageBackground />
      
      
    </>
  );
}
