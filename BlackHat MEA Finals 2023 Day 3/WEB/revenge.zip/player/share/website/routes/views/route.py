from flask import Blueprint


web = Blueprint("web", __name__)