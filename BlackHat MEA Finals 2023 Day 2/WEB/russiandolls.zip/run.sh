#! /bin/bash
node index.js >/dev/null 2>/dev/null &
sleep 2
while true; do
    socat - TCP:127.0.0.1:3000,forever
done