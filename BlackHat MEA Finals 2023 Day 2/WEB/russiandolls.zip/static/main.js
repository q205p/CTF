const init = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get("error");
    showError(myParam);
};
const register = async (event) => {
    event.preventDefault();
    const username = document.querySelector("#username").value;
    const password = document.querySelector("#password").value;

    await fetch("/register", {
        method: "POST",
        body: JSON.stringify({ username, password }),
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then((resp) => resp.json())
        .then((resp) => {
            if (resp.success) {
                document.location = "/";
            } else if (resp.error) {
                showError(resp.error.message);
            }
        });
};

const login = async (event) => {
    event.preventDefault();
    const username = document.querySelector("#username").value;
    const password = document.querySelector("#password").value;

    await fetch("/login", {
        method: "POST",
        body: JSON.stringify({ username, password }),
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then((resp) => resp.json())
        .then((resp) => {
            if (resp.success) {
                document.location = "/";
            } else if (resp.error) {
                showError(resp.error.message);
            }
        });
};

function showError(error) {
    const errorText = document.querySelector("#error");
    const errorCard = document.querySelector("#error-card");
    errorText.textContent = error;
    errorCard.style.display = "block";
}

const saveNote = async (event) => {
    event.preventDefault();
    const note = {
        title: document.querySelector("#title").value,
        content: document.querySelector("#content").value,
    };
    alert(1)

    await fetch("/", {
        method: "POST",
        body: JSON.stringify({ note }),
        headers: {
            "Content-Type": "application/json",
        },
    }).then(resp => resp.json()).then(resp => {
        alert(1);
        if (resp.success) {
            document.location.reload();
        }
        else if (resp.error) {
            showError(resp.error.message);
        }
    })
};
