# Tested with Python 3.11, should work on any modern python version
# You should notice this is a different implementation from the Easy challenge
# All this is **MEANT** to do is hold a persistent session with nsjail to prevent restarts
# If you want to complain that I wrote a bad proxy, you're right
# You can shame me in a ticket on Discord, I'll be happy to learn how to do it better
# !!! The challenge is NOT here, this is just a proxy to keep the session alive

import socket
import http.server
import threading


# Create the threading lock
lock = threading.Lock()

# Connect to the server
HOST = "127.0.0.1"
PORT = 1337

# Create a socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.settimeout(1)
s.connect((HOST, PORT))

# Listen on a different port with a socket server
LISTENING_PORT = 5000


# Build an http server that forwards requests to the socket
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        print(f"GET {self.path}")
        with lock:
            # Assemble the request again
            request = self.requestline + "\r\n"
            for header in self.headers:
                request += header + ": " + self.headers[header] + "\r\n"
            request += "\r\n"

            # Send the request to the socket
            s.sendall(request.encode())

            # Receive the response
            response = b""
            s.settimeout(2)
            while True:
                try:
                    response += s.recv(1024)
                except socket.timeout:
                    break

            # Send the response back to the client
            self.wfile.write(response)

    def do_POST(self):
        try:
            print(f"POST {self.path}")
            # Assemble the request again
            with lock:
                request = self.requestline.encode() + b"\r\n"
                for header in self.headers:
                    request += (
                        header.encode()
                        + b": "
                        + self.headers[header].encode()
                        + b"\r\n"
                    )

                # Read the POST body
                if "Content-Length" in self.headers:
                    content_length = int(self.headers["Content-Length"])
                    request += b"\r\n" + self.rfile.read(content_length)
                request += b"\r\n"

                # Send the request to the socket
                s.sendall(request)

                # Receive the response
                response = b""

                # Setting socket timeout
                s.settimeout(2)
                while True:
                    try:
                        response += s.recv(1024)
                    except socket.timeout:
                        break

                # Send the response back to the client
                self.wfile.write(response)
        except Exception as e:
            print(e)


# Listen with socket reusing the same port
print("Listening on port " + str(LISTENING_PORT) + "...")
httpd = http.server.ThreadingHTTPServer(("", LISTENING_PORT), Handler)
httpd.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
httpd.serve_forever()
