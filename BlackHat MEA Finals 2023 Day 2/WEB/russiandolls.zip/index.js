#! /usr/bin/node
const objSerializer = require("node-serialize");
const { Waf: WAF } = require("./utils");
const path = require("path");
const bufferSerializer = require("buffer-serializer");
const fastify = require("fastify")();

const crypto = require("node:crypto");
const { hashPassword, comparePassword } = require("./utils");
const { findUser, addUser, getUsersFromDatabase, initializeDatabase, cleanDatabase } = require("./database");

fastify.register(require("@fastify/cookie"), {
	secret: crypto.randomBytes(32).toString("hex"),
});

fastify.register(require("@fastify/static"), {
	root: path.join(__dirname, "static"),
	prefix: "/static/",
});

fastify.register(require("@fastify/view"), {
	engine: {
		ejs: require("ejs"),
	},
});

global.serializer = new bufferSerializer();

const isAdmin = async (req, reply, done) => {
	if (req.cookies.username) {
		const { valid, value } = req.unsignCookie(req.cookies.username);
		if (valid) {
			const user = await findUser(value);
			if (user && user.admin === 1) {
				req.username = value;
				return done();
			}
		}
	}

	reply.code(403).send({ message: "UNAUTHORIZED, ONLY ADMIN !" });
};

const isLoggedIn = async (req, reply, done) => {
	if (req.cookies.username) {
		const { valid, value } = req.unsignCookie(req.cookies.username);
		if (valid) {
			const user = await findUser(value);
			if (user) {
				req.username = value;
				return done();
			}
		}
	}

	reply.redirect("/login?error=" + encodeURIComponent("Please login first !"));
};

fastify.post("/login", async (req, reply) => {
	if (!req.body.username || !req.body.password) {
		return reply.code(400).send({ error: "username and password are required" })
	}

	const user = await findUser(req.body.username);
	if (user) {
		if (comparePassword(req.body.password, user.password)) {
			reply.cookie("username", req.body.username, {
				httpOnly: true,
				secure: false,
				signed: true,
			});

			return reply.send({
				success: true,
			});
		}
	}

	return reply.status(400).send({ error: "error while logging " });
});

fastify.get("/login", async (_, reply) => {
	return reply.view("templates/login.ejs");
});

fastify.get("/register", async (_, reply) => {
	return reply.view("templates/register.ejs");
});

fastify.post("/register", async (req, reply) => {
	const { username, password } = req.body;
	if (!username || !password) {
		return reply.status(400).send({
			error: {
				message: "please password and username are required",
			},
		});
	}

	const user = await findUser(username);

	if (user) {
		return reply.status(400).send({
			error: {
				message: "Please try with another username",
			},
		});
	}


	const newUser = await addUser(username, hashPassword(password))

	if (!newUser) {
		return reply.code(500).send({ error: 'error adding user' })
	}

	reply.cookie("username", username, {
		httpOnly: true,
		secure: false,
		signed: true,
	});

	return reply.send({ success: true });
});

fastify.get("/users", { preHandler: isAdmin }, async (_, reply) => {
	const usersArray = await getUsersFromDatabase()

	return reply.view("templates/admin.ejs", {
		users: usersArray,
	});
});

fastify.get("/", { preHandler: isLoggedIn }, async (req, reply) => {
	let notes = [];
	if (req.cookies.notes) {
		const { valid, value } = req.unsignCookie(req.cookies.notes);

		if (!valid) {
			reply.clearCookie("notes");
			return reply.code(400).send({ error: { message: "Something is wrong" } });
		}
		const decodedCookie = Buffer.from(value, "base64");

		notes = global.serializer.fromBuffer(decodedCookie).map((x) => {
			new WAF(objSerializer, x);
			return objSerializer.unserialize(x);
		});

	}

	const { value } = req.unsignCookie(req.cookies.username);

	return reply.view("templates/index.ejs", {
		user: { username: value },
		notes,
	});
});

fastify.post("/", { preHandler: isLoggedIn }, async (req, reply) => {

	try {
		new WAF(objSerializer, req.body.note);
	} catch (e) {
		return reply.code(400).send(e);
	}

	if (req.body.note) {
		if (req.cookies.notes) {
			const { valid, value } = req.unsignCookie(req.cookies.notes);
			if (valid) {
				const decodedBuffer = Buffer.from(value, "base64");

				const notes = global.serializer.fromBuffer(decodedBuffer);
				notes.push(objSerializer.serialize(req.body.note));

				const serializedNotes = global.serializer.toBuffer(notes);
				reply.cookie("notes", serializedNotes.toString("base64"), {
					signed: true,
					httpOnly: true,
					secure: false,
				});
			} else {
				reply.clearCookie("notes");
			}
		} else {
			const serializedNote = objSerializer.serialize(req.body.note);
			reply.cookie(
				"notes",
				global.serializer.toBuffer([serializedNote]).toString("base64"),
				{
					signed: true,
					httpOnly: true,
					secure: false,
				}
			);
		}
		return reply.send({
			success: true,
		});
	}

	return reply.code(400).send({
		error: {
			message: "Bad note",
		},
	});
});

fastify.get("*", async (req, reply) => {
	return reply.code(404);
});

// Start the server.
const start = async () => {
	try {
		await initializeDatabase()
		setInterval(cleanDatabase, 300000);

		await fastify.listen({
			host: "0.0.0.0",
			port: 3000,
		})

		console.log(`server listening on ${fastify.server.address().port}`);
	} catch (err) {
		fastify.log.error(err);
		process.exit(1);
	}
};

start();
