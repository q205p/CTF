const sqlite3 = require('sqlite3').verbose();
global.db = new sqlite3.Database('users.db');

async function findUser(username) {
    return new Promise((resolve, reject) => {
        db.get("SELECT * FROM users WHERE username = ?", username, (err, user) => {
            if (err) {
                reject(null);
            } else {
                resolve(user);
            }
        });
    });
}

async function addUser(username, hashedPassword) {
    return new Promise((resolve, reject) => {
        db.run("INSERT INTO users (username, password, admin) VALUES (?, ?, ?)", username, hashedPassword, 0, (err) => {
            if (err) {
                reject(null);
            } else {
                resolve({
                    username,
                    admin: false,
                });
            }
        });
    })
}

async function getUsersFromDatabase() {
    return new Promise((resolve, reject) => {
        db.all("SELECT username, admin FROM users", (err, rows) => {
            if (err) {
                reject([]);
            } else {
                resolve(rows);
            }
        });
    });
}

async function deleteUser(username) {
    return new Promise((resolve, reject) => {
        db.all(`DELETE FROM users where username='${username}'`, (err, rows) => {
            if (err) {
                reject([]);
            } else {
                resolve(rows);
            }
        });
    });

}

async function cleanDatabase() {
    try {
        await new Promise((resolve, reject) => {
            db.run("DELETE FROM users", (err) => {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            });
        });
        console.log('Database cleaned.');
    } catch (err) {
        console.error('Error cleaning the database:', err);
    }
}

async function initializeDatabase() {
    try {
        await new Promise((resolve, reject) => {
            db.run(`
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            admin INTEGER
        )
            `, (err) => {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            });
        });
        console.log('Database initialized.');
    } catch (err) {
        console.error('Error initializing the database:', err);
    }
}


module.exports = { addUser, findUser, getUsersFromDatabase, initializeDatabase, cleanDatabase, db, deleteUser }
challenge