const { createHmac, createHash } = require("node:crypto");
const vm = require("vm");

function signString(secret, message) {
	return createHmac("sha256", secret).update(message).digest("base64");
}

function hashPassword(password) {
	return createHash("sha256").update(password).digest("hex");
}
function comparePassword(password, hash) {
	console.log(hashPassword(password), password)
	return hashPassword(password) === hash;
}

const blacklist = [
	"atob",
	"btoa",
	"process",
	"exec",
	"Function",
	"require",
	"module",
	"global",
	"console",
	"+",
	"-",
	"*",
	"/",
	"===",
	"<",
	">=",
	"<=",
	"&&",
	"||",
	"new",
	"users",
	"[",
	"]",
	"Array",
	"constructor",
	"__proto__",
	"prototype",
	"hasOwnProperty",
	"valueOf",
	"toString",
	"charCodeAt",
	"fromCharCode",
	"string",
	"slice",
	"split",
	"join",
	"substr",
	"substring",
	"RegExp",
	"test",
	"match",
	"db",
	"Buffer",
	"setTimeout",
	"setInterval",
	"setImmediate",
	"Promise",
	"async",
	"await",
	"throw",
	"catch",
];

class Waf {
	constructor(serializer, any) {
		let value = any;
		if (typeof any === "object") {
			value = serializer.serialize(any);
		}

		if (value.length > 130) {
			throw new Error({
				message: "too long, no DDOS",
			});
		}

		for (let i = 0; i < blacklist.length; i++) {
			if (value.includes(blacklist[i])) {
				console.log(blacklist[i]);
				throw new Error({
					message: "not safe",
				});
			}
		}
		const result = vm.runInContext(
			` serializer.unserialize(value); `,
			vm.createContext({ value, serializer }),
			{ timeout: 1000 }
		);

		if (
			(typeof result === "string" ||
				(typeof result === "object" && result instanceof Array)) &&
			result.includes(process.env.FLAG)
		) {
			throw new Error({
				message: "nice try",
			});
		}
	}
}

module.exports = {
	Waf,
	signString,
	hashPassword,
	comparePassword,
};
