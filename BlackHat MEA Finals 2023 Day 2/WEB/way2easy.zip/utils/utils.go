package utils

import (
	"net/url"
	"strings"
)

func IsValidURL(u string) bool {
	parsedURL, err := url.Parse(u)
	if err != nil {
		return false
	}

	// Check the scheme is http
	if parsedURL.Scheme != "http" {
		return false
	}

	// Check the host is localhost:3000
	if parsedURL.Host != "localhost:3000" {
		return false
	}

	return true
}

func IsBlacklisted(input string) bool {
	blacklist := []string{
		"--", ";", "/*", "*/", "@@", "@", "char", "nchar", "varchar", "nvarchar",
		"alter", "begin", "cast", "create", "cursor", "declare", "delete", "drop", "end",
		"exec", "execute", "fetch", "insert", "kill", "open", "select", "sys", "sysobjects", "union",
		"syscolumns", "table", "update",
	}

	for _, keyword := range blacklist {
		if strings.Contains(strings.ToLower(input), keyword) {
			return true
		}
	}
	return false
}
