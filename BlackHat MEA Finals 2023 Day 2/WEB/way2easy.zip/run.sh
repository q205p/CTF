#!/bin/bash
/app/server >/dev/null 2>&1 &
while true; do
    socat - TCP:127.0.0.1:3000,forever
done
