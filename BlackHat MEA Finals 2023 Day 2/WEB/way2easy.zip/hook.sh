#!/bin/sh
# Workaround for nsjail issues
python /jail/proxy.py &

# Make nsjail rw on the root system since this challenge has no RCE anyways
sed -i "s/nodev:true/nodev:true  rw:true/" /tmp/nsjail.cfg

