package main

import (
	"database/sql"
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"
	"os"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"

	"workspace/handlers"
	customMiddlewares "workspace/middlewares"
	"workspace/utils"

	"github.com/gorilla/sessions"
	"github.com/labstack/echo-contrib/session"
	_ "github.com/mattn/go-sqlite3"
)

var note string

func init() {
	setup()
}

func main() {
	e := echo.New()
	e.Use(session.Middleware(sessions.NewCookieStore([]byte(os.Getenv("SECRET_KEY")))))

	t := &Template{}
	e.Renderer = t

	// Middleware
	e.Use(middleware.Logger())
	e.Use(middleware.Recover())

	// Routes
	e.POST("/login", handlers.HandleLogin)
	e.GET("/login", handlers.ViewLogin)
	e.POST("/secret-door", handlers.SecretDoor, customMiddlewares.CheckSession)
	e.GET("/secret-note", handlers.ViewSecretNote)
	e.POST("/keeper", handlers.HandleKeeper, customMiddlewares.CheckSession)
	e.GET("/bot", handlers.ViewBot)
	e.POST("/report", handlers.Report)
	e.GET("/keeper", handlers.ViewKeeper)

	e.Static("/static", "static") // Serves the static files
	e.HTTPErrorHandler = customHTTPErrorHandler

	defer utils.Db.Close()

	// Start the server
	e.Start(":3000")
}

// Template structure for rendering
type Template struct {
	templates *template.Template
}

func (t *Template) Render(w io.Writer, name string, data interface{}, c echo.Context) error {
	if t.templates == nil {
		t.templates = template.Must(template.ParseGlob("templates/*.html"))
	}
	return t.templates.ExecuteTemplate(w, name, data)
}

func customHTTPErrorHandler(err error, c echo.Context) {
	he, ok := err.(*echo.HTTPError)

	if ok {
		if he.Code == http.StatusNotFound {
			c.Redirect(http.StatusSeeOther, "/login")
			return
		}
	}

	c.Echo().DefaultHTTPErrorHandler(err, c)
}

func setup() {
	db, err := sql.Open("sqlite3", "./sql.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Define SQL commands

	statements := []string{
		fmt.Sprintf(`INSERT OR IGNORE INTO users (username, password) VALUES ('%s', '%s');`,
			os.Getenv("USERNAME"), os.Getenv("PASSWORD")),
		fmt.Sprintf(`INSERT OR IGNORE INTO masterKeys(master_key) VALUES('%s');`,
			os.Getenv("FLAG")),
	}

	// Execute SQL commands
	for _, stmt := range statements {
		fmt.Println("Executing", stmt)
		_, err := db.Exec(stmt)
		if err != nil {
			log.Fatalf("Failed to execute statement: %v", err)
		}
	}
}
