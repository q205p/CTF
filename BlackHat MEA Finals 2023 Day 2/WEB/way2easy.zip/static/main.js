function getQueryParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

function simpleMarkdownToHTML(md) {
    let html = md;

    // Convert headers
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^#### (.*$)/gim, '<h4>$1</h4>');


    // Convert images
    html = html.replace(/!\[(.*?)\]\((.*?)\)/gim, '<img src="$2" alt="$1">');

    // Convert links
    html = html.replace(/\[(.*?)\]\((.*?)\)/gim, '<a href="$2">$1</a>');

    // Convert bold text
    html = html.replace(/\*\*(.*?)\*\*/gim, '<b>$1</b>');
    html = html.replace(/__(.*?)__/gim, '<b>$1</b>');


    // Convert italic text
    html = html.replace(/\*(.*?)\*/gim, '<i>$1</i>');
    html = html.replace(/_(.*?)_/gim, '<i>$1</i>');

    // Convert blockquotes
    html = html.replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>');

    return html;
}


function init() {
    document.addEventListener("DOMContentLoaded", function () {
        let note = getQueryParam('note');

        if (note) {

            if (typeof note === "string" && note.length > 150) {
                note = "Here is a placeholder note as yours is so long "
            }
            else {
                const currNote = atob(note)
                const safeHTML = DOMPurify.sanitize(currNote);
                note = simpleMarkdownToHTML(safeHTML);
            }

        } else {
            console.warn('No note query parameter set.');
            note = "Who Doesn't love cats"
        }


        document.getElementById('noteOutput').innerHTML = note;
    });
}