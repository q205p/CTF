package handlers

import (
	"fmt"
	"net/http"
	"strings"
	"workspace/utils"

	"github.com/labstack/echo/v4"
)

func HandleKeeper(c echo.Context) error {
	// Get the payload from the POST form data
	payload := c.FormValue("payload")

	// Insert the payload into the vault table
	_, err := utils.Db.Exec("INSERT INTO vault (payload) VALUES (?)", payload)
	if err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Failed to save payload")
	}

	return c.String(http.StatusOK, "Payload saved successfully!")
}

func ViewKeeper(c echo.Context) error {

	var payloads []string
	rows, err := utils.Db.Query("SELECT payload FROM vault")
	if err != nil {
		fmt.Println(err)
		return echo.NewHTTPError(http.StatusInternalServerError, "Restart instance")
	}

	defer rows.Close()

	for rows.Next() {

		var x string
		if err := rows.Scan(&x); err != nil {
			return echo.NewHTTPError(http.StatusInternalServerError, "Restart instance")
		}

		payloads = append(payloads, x)
	}

	if err := rows.Err(); err != nil {
		panic(err)
	}

	return c.String(200, strings.Join(payloads, "-------------------\n"))

}
