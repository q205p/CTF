package handlers

import (
	"database/sql"
	"fmt"
	"workspace/utils"

	"github.com/labstack/echo/v4"
)

func SecretDoor(c echo.Context) error {

	master_key := c.FormValue("master_key")

	if master_key != "" && !utils.IsBlacklisted(master_key) {
		var id string

		err := utils.Db.QueryRow(fmt.Sprintf("SELECT id FROM masterKeys WHERE master_key = '%s'", master_key)).Scan(&id)

		if err != nil {
			if err == sql.ErrNoRows {
				return echo.ErrBadRequest
			}
			return echo.ErrInternalServerError
		}

	}

	return c.NoContent(200)
}
