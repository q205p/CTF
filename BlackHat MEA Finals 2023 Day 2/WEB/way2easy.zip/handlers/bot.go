package handlers

import (
	"context"
	"fmt"
	"os"
	"time"
	"workspace/utils"

	"github.com/chromedp/chromedp"

	"github.com/labstack/echo/v4"

	_ "github.com/mattn/go-sqlite3"
)

func ViewBot(c echo.Context) error {
	return c.Render(200, "bot.html", nil)
}

func Report(c echo.Context) error {
	url := c.FormValue("url")
	if utils.IsValidURL(url) {
		NavigateAndLogin(url)
		return c.String(200, "[+] The bot visited the url")
	} else {
		return c.String(400, "[-] Beter url")
	}
}

func NavigateAndLogin(targetURL string) error {
	var err error

	// create context
	opts := append(chromedp.DefaultExecAllocatorOptions[:],
		chromedp.Flag("headless", true), // run in headless mode
		chromedp.Flag("disable-gpu", true), // disable GPU
		chromedp.Flag("no-first-run", true),
		chromedp.Flag("no-default-browser-check", true),
		chromedp.Flag("disable-dev-shm-usage", true), // overcome limited resource problems
		chromedp.Flag("no-sandbox", true), // Bypass OS security model
		chromedp.Flag("disable-setuid-sandbox", true),
		chromedp.Flag("disable-web-security", true),
		chromedp.Flag("ignore-certificate-errors", true),
		chromedp.Flag("disable-software-rasterizer", true),
		chromedp.Flag("disable-client-side-phishing-detection", true),
		chromedp.Flag("disable-extensions", true), // disabling extensions
		chromedp.Flag("disable-popup-blocking", true), // disabling popup blocking
	)
	alloCtx, cancel := chromedp.NewExecAllocator(context.Background(), opts...)
	defer cancel()

	ctx, cancel := chromedp.NewContext(alloCtx)
	ctx, cancel = context.WithTimeout(ctx, 30*time.Second)

	// set some timeout to prevent indefinite waiting
	defer cancel()

	fmt.Println(os.Getenv("USERNAME"), os.Getenv("PASSWORD"))

	// tasks to perform
	err = chromedp.Run(ctx,
		// navigate to /login
		chromedp.Navigate(`http://localhost:3000/login`),
		chromedp.WaitVisible(`form`),

		// fill username
		chromedp.SendKeys(`input[name="username"]`, os.Getenv("USERNAME")),

		// fill password
		chromedp.SendKeys(`input[name="password"]`, os.Getenv("PASSWORD")),

		// submit form - assuming there's a button of type submit for login
		chromedp.Submit(`form`),

		// wait a bit for potential redirections after login
		chromedp.Sleep(1*time.Second),

		// navigate to the target page
		chromedp.Navigate(targetURL),

		chromedp.Sleep(15*time.Minute),
	)

	fmt.Println(err)

	return err
}
