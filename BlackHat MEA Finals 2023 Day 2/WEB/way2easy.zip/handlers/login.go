package handlers

import (
	"database/sql"
	"net/http"
	"workspace/utils"

	"github.com/gorilla/sessions"
	"github.com/labstack/echo-contrib/session"
	"github.com/labstack/echo/v4"
)

func ViewLogin(c echo.Context) error {
	return c.Render(http.StatusOK, "login.html", nil)
}

func HandleLogin(c echo.Context) error {
	username := c.FormValue("username")
	password := c.FormValue("password")

	if utils.IsBlacklisted(username) || utils.IsBlacklisted(password) {
		return echo.ErrBadRequest
	}

	// Check the username and password against the database
	var storedPassword string

	err := utils.Db.QueryRow("SELECT password FROM users WHERE username = ?", username).Scan(&storedPassword)
	if err != nil {
		if err == sql.ErrNoRows {
			return echo.ErrUnauthorized
		}
		return echo.ErrInternalServerError
	}

	if password != storedPassword {
		return echo.ErrUnauthorized
	}

	sess, _ := session.Get("session", c)
	sess.Options = &sessions.Options{
		Path:     "/",
		MaxAge:   86400 * 7,
		HttpOnly: true,
	}
	sess.Values["logged_in"] = true
	sess.Save(c.Request(), c.Response())

	return c.Redirect(301, "/secret-note")
}
