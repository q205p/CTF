-- This file should undo anything in `up.sql`

DROP TABLE users;
DROP TABLE producer_song;
DROP TABLE artists;
DROP TABLE songs;

