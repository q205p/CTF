#! /bin/sh
sed -i "s/nodev:true/nodev:true  rw:true/" /tmp/nsjail.cfg
echo $DYN_FLAG > /srv/app/$(cat /dev/urandom | tr -cd 'a-f0-9' | head -c 32)
