use std::io;

use axum::{http::StatusCode, response::IntoResponse, routing::get_service, Router};
use tower_http::services::{ServeDir, ServeFile};

use self::{
    artists::ArtistsRoutes, auth::AuthRoutes, converter::ConvertSongsRoutes, songs::SongsRoutes,
};

pub mod artists;
pub mod auth;
pub mod common;
pub mod converter;
pub mod songs;
pub mod static_files;

async fn handle_error(_err: io::Error) -> impl IntoResponse {
    (StatusCode::INTERNAL_SERVER_ERROR, "Something went wrong...")
}
pub fn create_router() -> Router {
    let songs_router = SongsRoutes {};
    let auth_router = AuthRoutes {};
    let producers_router = ArtistsRoutes {};
    let converter_router = ConvertSongsRoutes {};

    let serve_react = get_service(ServeFile::new("./app/index.html")).handle_error(handle_error);
    let serve_assets = get_service(ServeDir::new("./app/assets")).handle_error(handle_error);
    let serve_assets2 = get_service(ServeFile::new("./app/logo.png")).handle_error(handle_error);

    Router::new()
        .nest("/api/auth", auth_router.routes())
        .nest("/api/artists", producers_router.routes())
        .nest("/api/songs", songs_router.routes())
        .nest("/api/convert", converter_router.routes())
        .nest("/static", static_files::two_serve_dirs())
        .nest_service("/", serve_react)
        .nest_service("/assets", serve_assets)
        .nest_service("/logo.png", serve_assets2)
}
