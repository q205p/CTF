use diesel::prelude::*;
use std::env;

#[derive(Clone)]
pub struct EnvConfig {
    pub port: u16,
    pub host: String,
}

impl EnvConfig {
    pub fn new() -> Self {
        let port = env::var("PORT").expect("PORT must be set");
        let host = env::var("HOST").expect("HOST must be set");

        Self {
            port: port.parse().unwrap(),
            host,
        }
    }
}

pub fn database_connection() -> SqliteConnection {
    let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");
    SqliteConnection::establish(&database_url)
        .unwrap_or_else(|_| panic!("Error connecting to {}", "sql.db"))
}
