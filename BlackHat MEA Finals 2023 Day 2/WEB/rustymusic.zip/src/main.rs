use axum::Router;
use dotenvy::dotenv;
use std::net::SocketAddr;
use tower_http::{
    cors::{Any, CorsLayer},
    trace::TraceLayer,
};

use crate::{handlers::create_router, repositories::seed};
mod config;
mod extractors;
mod handlers;
mod middlewares;
mod repositories;
mod schema;
mod utils;

#[tokio::main]
async fn main() {
    dotenv().ok();
    seed();

    let env_config = config::EnvConfig::new();

    if std::env::var_os("RUST_LOG").is_none() {
        std::env::set_var(
            "RUST_LOG",
            "example_tracing_aka_logging=debug,tower_http=debug",
        )
    }

    tracing_subscriber::fmt::init();

    let router = create_router();
    let app = Router::new()
        .merge(router)
        .layer(TraceLayer::new_for_http())
        .layer(
            CorsLayer::new()
                .allow_origin(Any)
                .allow_methods(Any)
                .allow_headers(Any),
        );

    // run it
    let addr = SocketAddr::from(([0, 0, 0, 0], env_config.port));
    println!("listening on {}", addr);
    axum::Server::bind(&addr)
        .serve(app.into_make_service())
        .await
        .unwrap();
}
