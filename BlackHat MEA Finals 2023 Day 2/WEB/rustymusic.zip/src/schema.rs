// @generated automatically by Diesel CLI.

diesel::table! {
    artist_song (artist_key, song_key) {
        artist_key -> Integer,
        song_key -> Integer,
    }
}

diesel::table! {
    artists (id) {
        id -> Integer,
        name -> Text,
        description -> Text,
        started_at -> Nullable<Text>,
        origin_country -> Text,
    }
}

diesel::table! {
    songs (id) {
        id -> Integer,
        name -> Text,
        date_of_release -> Text,
        song_file -> Text,
        song_cover -> Nullable<Text>,
        artist_id -> Integer,
    }
}

diesel::table! {
    users (id) {
        id -> Integer,
        username -> Text,
        email -> Text,
        password -> Text,
        role -> Text,
    }
}

diesel::joinable!(artist_song -> artists (artist_key));
diesel::joinable!(artist_song -> songs (song_key));
diesel::joinable!(songs -> artists (artist_id));

diesel::allow_tables_to_appear_in_same_query!(artist_song, artists, songs, users,);
