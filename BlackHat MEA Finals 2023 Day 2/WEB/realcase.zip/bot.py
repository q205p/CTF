"""
Can you spot the XSS here by reviewing the code ? Disclose responsibly, have fun!
https://gitlab.ow2.org/lemonldap-ng/lemonldap-ng/-/tree/v2.0.9/

PS: To make up for yesterday's XSS bots having no internet, this one does! Happy hacking!
"""

import os
from .route import web
from flask import Flask, request, jsonify
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import threading
import queue
from website.config import MAX_CONCURRENT_THREADS, FLAG
import re
import sys

thread_local = threading.local()
url_queue = queue.Queue()


def get_webdriver():
    if not hasattr(thread_local, "webdriver"):
        options = webdriver.ChromeOptions()
        options.add_argument("--no-sandbox")
        options.add_argument("--headless")
        options.add_argument("--ignore-certificate-errors")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-infobars")
        options.add_argument("--disable-background-networking")
        options.add_argument("--disable-default-apps")
        options.add_argument("--disable-extensions")
        options.add_argument("--disable-gpu")
        options.add_argument("--disable-sync")
        options.add_argument("--disable-translate")
        options.add_argument("--hide-scrollbars")
        options.add_argument("--metrics-recording-only")
        options.add_argument("--no-first-run")
        options.add_argument("--safebrowsing-disable-auto-update")
        options.add_argument("--media-cache-size=1")
        options.add_argument("--disk-cache-size=1")

        driver = webdriver.Chrome(options=options)

        thread_local.webdriver = driver

    return thread_local.webdriver


def release_webdriver():
    if hasattr(thread_local, "webdriver"):
        thread_local.webdriver.quit()
        del thread_local.webdriver


def process_url(url):
    try:
        driver = get_webdriver()
        driver.get("http://auth.example.com/")
        # login here
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "user"))
        )
        username = driver.find_element(By.NAME, "user")
        password = driver.find_element(By.NAME, "password")
        username.send_keys("dwho")
        password.send_keys("dwho")
        submitButton = driver.find_element(By.CLASS_NAME, "btn-success")
        submitButton.click()
        time.sleep(2)
        driver.add_cookie({"name": "flag", "value": FLAG, "domain": "example.com"})
        driver.get(url)
        time.sleep(5)
        return "done"
    except Exception as e:
        return "Error: {}".format(str(e))


def process_queue():
    while True:
        try:
            if threading.active_count() <= int(MAX_CONCURRENT_THREADS):
                threading.Thread(
                    target=process_and_release, args=(url_queue.get(),)
                ).start()
            else:
                time.sleep(1)
        except queue.Empty:
            time.sleep(1)


def process_and_release(url):
    try:
        result = process_url(url)
    finally:
        url_queue.task_done()
        release_webdriver()


url_processing_thread = threading.Thread(target=process_queue)
url_processing_thread.daemon = True
url_processing_thread.start()


def use_regex(input_text):
    pattern = re.compile(r"http://auth.example.com/", re.IGNORECASE)
    pattern2 = re.compile(r"http://manager.example.com/", re.IGNORECASE)
    pattern3 = re.compile(r"http://localhost:8080/", re.IGNORECASE)
    return (
        pattern.match(input_text)
        or pattern2.match(input_text)
        or pattern3.match(input_text)
    )


@web.route("/bott", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        if use_regex(url):
            url_queue.put(url)
            return "URL added to the waiting list"
    return "You can only try with auth.example.com or manager.example.com or localhost:8080"
